<?php
defined('ABSPATH') || exit;
global $product;

if (! $product || ! $product->is_visible()) {
	return;
}
?>

<article <?php wc_product_class('ff-menu-card js-menu-product-trigger', $product); ?> data-product-id="<?php echo esc_attr($product->get_id()); ?>">
	<div class="ff-menu-card__inner">
		<div class="ff-menu-card__image">
			<?php echo $product->get_image('medium'); ?>
		</div>

		<div class="ff-menu-card__content">
			<h3 class="ff-menu-card__title"><?php echo esc_html($product->get_name()); ?></h3>

			<div class="ff-menu-card__price">
				<?php echo wp_kses_post($product->get_price_html()); ?>
			</div>

			<button
				type="button"
				class="ff-menu-card__open js-menu-product-trigger"
				data-product-id="<?php echo esc_attr($product->get_id()); ?>"
			>
				<?php esc_html_e('Customize', 'ffkebab'); ?>
			</button>
		</div>
	</div>
</article>