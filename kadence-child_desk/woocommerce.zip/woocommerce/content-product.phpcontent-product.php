<?php
defined( 'ABSPATH' ) || exit;

global $product;

if ( ! $product || ! $product->is_visible() ) {
	return;
}

$product_id  = $product->get_id();
$product_url = get_permalink( $product_id );
$price_html  = $product->get_price_html();
$weight      = $product->get_weight();
$unit        = get_option( 'woocommerce_weight_unit', 'g' );
$short_desc  = $product->get_short_description();

if ( '' === trim( wp_strip_all_tags( $short_desc ) ) ) {
	$short_desc = $product->get_description();
}

$short_desc = wp_trim_words( wp_strip_all_tags( $short_desc ), 16, '…' );
?>

<article <?php wc_product_class( 'ffk-product-card', $product ); ?>>
	<a class="ffk-product-card__image" href="<?php echo esc_url( $product_url ); ?>">
		<?php
		if ( has_post_thumbnail( $product_id ) ) {
			echo get_the_post_thumbnail( $product_id, 'medium_large' );
		} else {
			echo wc_placeholder_img( 'medium_large' );
		}
		?>
	</a>

	<div class="ffk-product-card__body">
		<h2 class="ffk-product-card__title">
			<a href="<?php echo esc_url( $product_url ); ?>">
				<?php echo esc_html( $product->get_name() ); ?>
			</a>
		</h2>

		<?php if ( $short_desc ) : ?>
			<div class="ffk-product-card__desc">
				<?php echo esc_html( $short_desc ); ?>
			</div>
		<?php endif; ?>

		<?php if ( '' !== $weight ) : ?>
			<div class="ffk-product-card__weight">
				<?php echo esc_html( $weight . ' ' . $unit ); ?>
			</div>
		<?php endif; ?>

		<div class="ffk-product-card__bottom">
			<div class="ffk-product-card__price">
				<?php echo wp_kses_post( $price_html ); ?>
			</div>

			<a class="ffk-product-card__button" href="<?php echo esc_url( $product_url ); ?>">
				Vezi produs
			</a>
		</div>
	</div>
</article>